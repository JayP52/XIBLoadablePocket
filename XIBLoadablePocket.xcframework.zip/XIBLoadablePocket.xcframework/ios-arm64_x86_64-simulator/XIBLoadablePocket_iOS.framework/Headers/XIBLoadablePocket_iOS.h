//
//  XIBLoadablePocket_iOS.h
//  XIBLoadablePocket-iOS
//
//  Created by Jay Patel on 12/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for XIBLoadablePocket_iOS.
FOUNDATION_EXPORT double XIBLoadablePocket_iOSVersionNumber;

//! Project version string for XIBLoadablePocket_iOS.
FOUNDATION_EXPORT const unsigned char XIBLoadablePocket_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XIBLoadablePocket_iOS/PublicHeader.h>


